/* Source and licensing information for the line(s) below can be found at http://localhost/DrupalWebsite/core/assets/vendor/jquery.ui/ui/form-min.js. */
/*! jQuery UI - v1.12.1 - 2017-03-31
* http://jqueryui.com
* Copyright jQuery Foundation and other contributors; Licensed  */
!function(a){"function"==typeof define&&define.amd?define(["jquery","./version"],a):a(jQuery)}(function(a){return a.fn.form=function(){return"string"==typeof this[0].form?this.closest("form"):a(this[0].form)}});
/* Source and licensing information for the above line(s) can be found at http://localhost/DrupalWebsite/core/assets/vendor/jquery.ui/ui/form-min.js. */